# Bitrise Extension for Google Chrome

## Install

1) Open url: `chrome://extensions`
2) Enable Developer mode<br>
![dev mode](/images/dev_mode.png "Developer Mode")
3) Click `Load unpacked extension...`<br>
![load ext](/images/load_ext.png "Load extension")
4) Finally select the current directory

You should see the Bitrise icon somewhere here:

![tray icon](/images/tray_icon.png "Tray Icon") 

## Features

 - Button on the Unauthorized panel to open optimus_prime with the build slug
 - Added optimus_prime ?build_slug and ?build_id url query support, if one of those filled it starts the query automatically
 - Wherever you select a text, you'll have a "Look up build" extension menu to quickly find the build in optimuse_prime
