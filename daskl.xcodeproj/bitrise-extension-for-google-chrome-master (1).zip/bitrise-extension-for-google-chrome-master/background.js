
function LookUpBuild(info, tab) { // todo: need to refresh pages opened by this to have the extension working properly
    if (isNaN(info.selectionText)) {
        chrome.tabs.create({
            url: "https://app.bitrise.io/optimus_prime?build_slug=" + info.selectionText,
        });
    } else {
        chrome.tabs.create({
            url: "https://app.bitrise.io/optimus_prime?build_id=" + info.selectionText,
        });
    }
}

chrome.contextMenus.create({
    title: "Look up build: %s",
    contexts: ["selection"],
    onclick: LookUpBuild,
});