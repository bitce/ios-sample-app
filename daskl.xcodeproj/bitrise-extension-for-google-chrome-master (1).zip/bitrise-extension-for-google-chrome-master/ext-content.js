

// add op button when unauthorized panel appears
if (window.location.href.includes("app.bitrise.io/build/")) {
    var splitURL = window.location.href.split("/")
    var build_slug = splitURL[splitURL.length - 1]

    if (document.title.includes("page you were looking for doesn't exist")) {
        var button = document.createElement("button");
        button.textContent = "Open in Optimus Prime"
        button.onclick = function () {
            window.location.href = "https://app.bitrise.io/optimus_prime?build_slug=" + build_slug
        }
        button.style = "margin: auto; display: block;margin-top: 60px;"
        document.body.insertBefore(button, document.body.firstChild)
    }
}

// parse op params and run query
if (window.location.href.includes("app.bitrise.io/optimus_prime")) {
    var ngElement = angular.element($("div.v3-content.ng-scope"))
    var ngScope = ngElement.scope()

    ngElement.ready(function () {
        var build_slug = getQueryStringValue("build_slug")
        if (build_slug != null && build_slug != undefined && build_slug !== "") {
            fetchBuild(ngScope, build_slug, false)
            return
        }

        var build_id = getQueryStringValue("build_id")
        if (build_id != null && build_id != undefined && build_id !== "") {
            fetchBuild(ngScope, build_id, true)
            return
        }
    })
}

function fetchBuild(ngScope, slugOrId, is_id) {
    // set drop-down to index 3
    ngScope.selectedAction = ngScope.actions[3]
    ngScope.$apply()

    // find controller and build slug input field
    var buildInfoElement = angular.element($("section.v4-formattedcontent.ng-scope"))
    var buildInfoScope = buildInfoElement.scope()
    var optimusPrimeGetBuildInfoCtrl = buildInfoScope.$parent.optimusPrimeGetBuildInfoCtrl

    // set input field value
    if (!is_id) {
        optimusPrimeGetBuildInfoCtrl.targetBuildFormData.buildSlug = slugOrId
    } else {
        optimusPrimeGetBuildInfoCtrl.targetBuildFormData.buildID = slugOrId
    }

    // get build info
    optimusPrimeGetBuildInfoCtrl.getTargetBuildInfo()
}

function getQueryStringValue(key) {
    return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}
