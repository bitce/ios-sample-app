window.name = 'NG_ENABLE_DEBUG_INFO!' + window.name;

var s = document.createElement('script');
s.src = chrome.extension.getURL('ext-content.js');

document.head.insertBefore(s,document.head.childNodes[0]);

s.onload = function() {
    s.parentNode.removeChild(s);
};